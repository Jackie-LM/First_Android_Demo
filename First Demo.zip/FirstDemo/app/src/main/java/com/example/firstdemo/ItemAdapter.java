package com.example.firstdemo;

import android.widget.ArrayAdapter;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

}
